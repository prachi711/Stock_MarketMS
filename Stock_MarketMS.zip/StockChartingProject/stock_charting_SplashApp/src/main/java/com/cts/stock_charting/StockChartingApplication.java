package com.cts.stock_charting;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StockChartingApplication {

	public static void main(String[] args) {
		SpringApplication.run(StockChartingApplication.class, args);
	}

}
