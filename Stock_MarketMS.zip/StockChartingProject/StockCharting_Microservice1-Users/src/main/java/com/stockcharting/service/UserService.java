package com.stockcharting.service;

import org.springframework.data.repository.CrudRepository; 

import com.stockcharting.beans.User;

public interface UserService extends CrudRepository<User, Integer>{

}
