package com.stc.business_logic;

public class Stock_Analysis {

}
