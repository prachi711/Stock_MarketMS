package com.stc.entity;

import java.sql.Date; 
import java.sql.Time;
import java.util.Arrays;
import javax.persistence.Column; 
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Past;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name="Stock")
public class Stock {
	@Id
	private String company_code;
	private String stock_exchange;
	private int current_price;
	
	@DateTimeFormat(pattern="dd-MM-yyyy")
	@Past
	private Date date;
	private Time time;
	public String getCompany_code() {
		return company_code;
	}
	public void setCompany_code(String company_code) {
		this.company_code = company_code;
	}
	public String getStock_exchange() {
		return stock_exchange;
	}
	public void setStock_exchange(String stock_exchange) {
		this.stock_exchange = stock_exchange;
	}
	public int getCurrent_price() {
		return current_price;
	}
	public void setCurrent_price(int current_price) {
		this.current_price = current_price;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public Time getTime() {
		return time;
	}
	public void setTime(Time time) {
		this.time = time;
	}
	@Override
	public String toString() {
		return String.format("Stock [company_code=%s, stock_exchange=%s, current_price=%s, date=%s, time=%s]",
				company_code, stock_exchange, current_price, date, time);
	}
	
	public Stock()
	{}
	
	public Stock(String company_code, String stock_exchange, int current_price, Date date, Time time) {
		super();
		this.company_code = company_code;
		this.stock_exchange = stock_exchange;
		this.current_price = current_price;
		this.date = date;
		this.time = time;
	}
	
}
