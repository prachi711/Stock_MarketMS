package com.stc.service;

public class StockServiceImpl implements StockService {

}
