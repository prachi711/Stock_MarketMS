package com.stc.repository;

public interface StockRepos {

}